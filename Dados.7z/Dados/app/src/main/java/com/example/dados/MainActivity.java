package com.example.dados;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fabStartGame;
    private RecyclerView recyclerDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fabStartGame = findViewById(R.id.fab_start_game);
        recyclerDados = findViewById(R.id.recycler_dados);

        recyclerViewDados.setLayoutManager(
                new LinearLayoutManager(this,
                        RecyclerView.VERTICAL,
                        false)
                //new GridLayoutManager(this,8)
        );


        fabStartGame.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(
                                getApplicationContext(),
                                AddGiftActivity.class
                        );
                        startActivity(intent);

                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();

        ArrayList<Gift> gifts = GiftRepository.getInstance().getAll();

        if(gifts.size() > 0){
            textViewGiftsNotFound.setVisibility(View.INVISIBLE);
        }else{
            textViewGiftsNotFound.setVisibility(View.VISIBLE);
        }

        recyclerViewGifts.setAdapter(new GiftAdapter(gifts));
    }
}
    }
}